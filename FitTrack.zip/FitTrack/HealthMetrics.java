/**
 * Interface describing the health calculations a profile must provide.
 */
public interface HealthMetrics {
    double calculateBMI();
    String getBMICategory();
    double calculateBMR();
    int getDailyCalorieGoal();
}
