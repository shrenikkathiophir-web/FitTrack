import java.io.IOException;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

/**
 * FitTrack - Fitness & Nutrition Tracker.
 * Entry point: loads saved data, then opens the main window.
 */
public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Theme.install();

            DataStore store = new DataStore();
            try {
                store.load();
            } catch (IOException e) {
                System.out.println("Could not load saved data: " + e.getMessage());
            }

            JFrame frame = new JFrame("FitTrack - Fitness & Nutrition Tracker");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setContentPane(new AppPanel(store));
            frame.setSize(1140, 760);
            frame.setMinimumSize(new java.awt.Dimension(1000, 700));
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }
}
