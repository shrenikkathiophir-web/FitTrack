/**
 * Custom checked exception used when the user types invalid data.
 */
public class InvalidInputException extends Exception {
    public InvalidInputException(String message) {
        super(message);
    }
}
