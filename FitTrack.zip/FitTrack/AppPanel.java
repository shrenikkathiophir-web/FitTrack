import java.awt.*;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

/**
 * The whole application window content: a sidebar on the left and
 * a CardLayout on the right that switches between the four screens.
 */
public class AppPanel extends JPanel {

    private final DataStore store;
    private final CardLayout cards = new CardLayout();
    private final JPanel content = new JPanel(cards);
    private final Map<String, Refreshable> screens = new LinkedHashMap<>();
    private final Map<String, JButton> navButtons = new LinkedHashMap<>();
    private String current = "Dashboard";

    public AppPanel(DataStore store) {
        this.store = store;
        setLayout(new BorderLayout());
        content.setBackground(Theme.BG);

        addScreen("Dashboard", new DashboardPanel(store));
        addScreen("Workouts", new WorkoutPanel(store));
        addScreen("Nutrition", new NutritionPanel(store));
        addScreen("Profile", new ProfilePanel(store));

        add(buildSidebar(), BorderLayout.WEST);
        add(content, BorderLayout.CENTER);
        showScreen("Dashboard");
    }

    /** Generic method: the panel must be both a JPanel and Refreshable. */
    private <T extends JPanel & Refreshable> void addScreen(String name, T panel) {
        content.add(panel, name);
        screens.put(name, panel);
    }

    public void showScreen(String name) {
        current = name;
        screens.get(name).refresh();
        cards.show(content, name);
        for (Map.Entry<String, JButton> e : navButtons.entrySet()) {
            boolean selected = e.getKey().equals(name);
            e.getValue().setBackground(selected ? Theme.ACCENT : Theme.SIDEBAR);
            e.getValue().setForeground(selected ? Theme.BG : Theme.TEXT);
        }
    }

    private JPanel buildSidebar() {
        JPanel top = new JPanel();
        top.setLayout(new BoxLayout(top, BoxLayout.Y_AXIS));
        top.setOpaque(false);

        JLabel brand = UI.label("FitTrack", new Font("SansSerif", Font.BOLD, 26), Theme.ACCENT);
        brand.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel tagline = UI.label("Fitness & Nutrition", Theme.SMALL, Theme.MUTED);
        tagline.setAlignmentX(Component.LEFT_ALIGNMENT);
        top.add(brand);
        top.add(tagline);
        top.add(Box.createVerticalStrut(28));

        for (String name : screens.keySet()) {
            JButton b = new JButton(name);
            b.setFont(Theme.BODY_BOLD);
            b.setHorizontalAlignment(SwingConstants.LEFT);
            b.setOpaque(true);
            b.setFocusPainted(false);
            b.setBorderPainted(false);
            b.setBorder(new EmptyBorder(11, 16, 11, 16));
            b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            b.setAlignmentX(Component.LEFT_ALIGNMENT);
            b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
            b.addActionListener(e -> showScreen(name));
            navButtons.put(name, b);
            top.add(b);
            top.add(Box.createVerticalStrut(6));
        }

        JButton demo = UI.button("Load Demo Data", Theme.FIELD, Theme.TEXT);
        demo.addActionListener(e -> loadDemo());

        JPanel sidebar = new JPanel(new BorderLayout());
        sidebar.setBackground(Theme.SIDEBAR);
        sidebar.setBorder(new EmptyBorder(26, 16, 20, 16));
        sidebar.setPreferredSize(new Dimension(210, 0));
        sidebar.add(top, BorderLayout.NORTH);
        sidebar.add(demo, BorderLayout.SOUTH);
        return sidebar;
    }

    private void loadDemo() {
        int answer = JOptionPane.showConfirmDialog(this,
                "This replaces your current data with a week of sample data.\nContinue?",
                "Load Demo Data", JOptionPane.YES_NO_OPTION);
        if (answer == JOptionPane.YES_OPTION) {
            store.loadSampleData();
            showScreen(current);
        }
    }
}
