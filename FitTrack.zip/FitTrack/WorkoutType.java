/**
 * Enum of workout types. Each constant stores a MET value (intensity)
 * which is used to estimate calories burned.
 */
public enum WorkoutType {
    RUNNING("Running", 9.8),
    CYCLING("Cycling", 7.5),
    WALKING("Walking", 3.5),
    STRENGTH("Strength Training", 5.0),
    HIIT("HIIT", 8.0),
    SWIMMING("Swimming", 7.0),
    YOGA("Yoga", 3.0);

    private final String label;
    private final double met;

    WorkoutType(String label, double met) {
        this.label = label;
        this.met = met;
    }

    public String getLabel() { return label; }

    /** Calories burned = MET x body weight (kg) x time (hours). */
    public int caloriesBurned(double weightKg, int minutes) {
        return (int) Math.round(met * weightKg * (minutes / 60.0));
    }

    @Override
    public String toString() { return label; }
}
