import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

/** Home screen: today's stats, two weekly charts and the latest workouts. */
public class DashboardPanel extends JPanel implements Refreshable {

    private final DataStore store;
    private final JLabel welcome = UI.label("", Theme.TITLE, Theme.TEXT);
    private final JPanel statsRow = new JPanel(new GridLayout(1, 4, 16, 0));
    private final ChartPanel burnedChart = new ChartPanel("Calories Burned - Last 7 Days", Theme.ACCENT);
    private final ChartPanel eatenChart = new ChartPanel("Calories Eaten - Last 7 Days", Theme.ORANGE);
    private final DefaultTableModel model = UI.model("Date", "Workout", "Type", "Minutes", "Calories");

    public DashboardPanel(DataStore store) {
        this.store = store;
        setBackground(Theme.BG);
        setLayout(new BorderLayout(0, 18));
        setBorder(new EmptyBorder(24, 28, 24, 28));

        // header: welcome text on the left, date on the right
        JPanel left = new JPanel();
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        left.setOpaque(false);
        left.add(welcome);
        left.add(UI.label("Here is your fitness summary for today.", Theme.BODY, Theme.MUTED));

        String today = LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale.ENGLISH));
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        header.add(left, BorderLayout.WEST);
        header.add(UI.label(today, Theme.BODY, Theme.MUTED), BorderLayout.EAST);

        // charts row
        JPanel charts = new JPanel(new GridLayout(1, 2, 16, 0));
        charts.setOpaque(false);
        charts.add(wrap(burnedChart));
        charts.add(wrap(eatenChart));

        // recent workouts card
        RoundedPanel recent = new RoundedPanel(Theme.CARD, new BorderLayout(0, 10));
        recent.add(UI.label("Recent Workouts", Theme.HEADING, Theme.TEXT), BorderLayout.NORTH);
        recent.add(UI.scroll(UI.table(model)), BorderLayout.CENTER);

        JPanel lower = new JPanel(new GridLayout(2, 1, 0, 18));
        lower.setOpaque(false);
        lower.add(charts);
        lower.add(recent);

        statsRow.setOpaque(false);
        statsRow.setPreferredSize(new Dimension(0, 108));

        JPanel body = new JPanel(new BorderLayout(0, 18));
        body.setOpaque(false);
        body.add(statsRow, BorderLayout.NORTH);
        body.add(lower, BorderLayout.CENTER);

        add(header, BorderLayout.NORTH);
        add(body, BorderLayout.CENTER);
    }

    private RoundedPanel wrap(JComponent inner) {
        RoundedPanel card = new RoundedPanel(Theme.CARD, new BorderLayout());
        card.add(inner, BorderLayout.CENTER);
        return card;
    }

    @Override
    public void refresh() {
        Profile profile = store.getProfile();
        LocalDate today = LocalDate.now();
        welcome.setText("Welcome back, " + profile.getName() + "!");

        statsRow.removeAll();
        statsRow.add(UI.statCard("Calories Burned", store.caloriesBurned(today) + " kcal", "Today", Theme.ACCENT));
        statsRow.add(UI.statCard("Calories Eaten", store.caloriesEaten(today) + " kcal",
                "Goal: " + profile.getDailyCalorieGoal() + " kcal", Theme.ORANGE));
        statsRow.add(UI.statCard("Workout Streak", store.getWorkoutStreak() + " days",
                store.totalWorkouts() + " workouts logged", Theme.BLUE));
        statsRow.add(UI.statCard("BMI", String.format("%.1f", profile.calculateBMI()),
                profile.getBMICategory(), Theme.PURPLE));
        statsRow.revalidate();
        statsRow.repaint();

        String[] labels = store.last7DayLabels();
        burnedChart.setData(labels, store.burnedLast7Days(), 0);
        eatenChart.setData(labels, store.eatenLast7Days(), profile.getDailyCalorieGoal());

        model.setRowCount(0);
        List<Workout> recent = store.getRecentWorkouts(5);
        for (Workout w : recent) {
            model.addRow(new Object[]{w.getDate(), w.getName(), w.getCategory(),
                    w.getMinutes(), w.getCalories() + " kcal"});
        }
    }
}
