import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

/** Screen where the user edits body details; BMI, BMR and daily targets are calculated. */
public class ProfilePanel extends JPanel implements Refreshable {

    private final DataStore store;
    private final JTextField nameField = UI.field("", 12);
    private final JTextField ageField = UI.field("", 12);
    private final JComboBox<Gender> genderBox = UI.combo(Gender.values());
    private final JTextField weightField = UI.field("", 12);
    private final JTextField heightField = UI.field("", 12);
    private final JComboBox<Goal> goalBox = UI.combo(Goal.values());

    private final JLabel bmiLabel = UI.label("", Theme.BIG, Theme.ACCENT);
    private final JLabel bmiNote = UI.label("", Theme.BODY, Theme.MUTED);
    private final JLabel bmrLabel = UI.label("", Theme.BODY_BOLD, Theme.TEXT);
    private final JLabel calLabel = UI.label("", Theme.BODY_BOLD, Theme.TEXT);
    private final JLabel proteinLabel = UI.label("", Theme.BODY_BOLD, Theme.TEXT);
    private final JLabel carbLabel = UI.label("", Theme.BODY_BOLD, Theme.TEXT);
    private final JLabel fatLabel = UI.label("", Theme.BODY_BOLD, Theme.TEXT);

    public ProfilePanel(DataStore store) {
        this.store = store;
        setBackground(Theme.BG);
        setLayout(new BorderLayout(0, 18));
        setBorder(new EmptyBorder(24, 28, 24, 28));

        // --- form card ---
        JPanel grid = new JPanel(new GridLayout(0, 2, 16, 14));
        grid.setOpaque(false);
        grid.add(UI.labeled("Name", nameField));
        grid.add(UI.labeled("Age", ageField));
        grid.add(UI.labeled("Gender", genderBox));
        grid.add(UI.labeled("Weight (kg)", weightField));
        grid.add(UI.labeled("Height (cm)", heightField));
        grid.add(UI.labeled("Goal", goalBox));

        JButton save = UI.button("Save Profile", Theme.ACCENT, Theme.BG);
        save.addActionListener(e -> saveProfile());
        JPanel saveWrap = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        saveWrap.setOpaque(false);
        saveWrap.add(save);

        RoundedPanel formCard = new RoundedPanel(Theme.CARD, new BorderLayout(0, 14));
        formCard.add(UI.label("Your Details", Theme.HEADING, Theme.TEXT), BorderLayout.NORTH);
        formCard.add(grid, BorderLayout.CENTER);
        formCard.add(saveWrap, BorderLayout.SOUTH);

        // --- results card ---
        JPanel bmiBox = new JPanel(new BorderLayout(0, 0));
        bmiBox.setOpaque(false);
        bmiBox.add(UI.label("Body Mass Index", Theme.BODY, Theme.MUTED), BorderLayout.NORTH);
        bmiBox.add(bmiLabel, BorderLayout.CENTER);
        bmiBox.add(bmiNote, BorderLayout.SOUTH);

        JPanel rows = new JPanel(new GridLayout(0, 2, 10, 12));
        rows.setOpaque(false);
        addRow(rows, "BMR (resting burn)", bmrLabel);
        addRow(rows, "Daily calorie goal", calLabel);
        addRow(rows, "Protein goal", proteinLabel);
        addRow(rows, "Carbs goal", carbLabel);
        addRow(rows, "Fat goal", fatLabel);

        JPanel resultsBody = new JPanel(new BorderLayout(0, 16));
        resultsBody.setOpaque(false);
        resultsBody.add(bmiBox, BorderLayout.NORTH);
        resultsBody.add(rows, BorderLayout.CENTER);

        RoundedPanel resultsCard = new RoundedPanel(Theme.CARD, new BorderLayout(0, 14));
        resultsCard.add(UI.label("Your Health Metrics", Theme.HEADING, Theme.TEXT), BorderLayout.NORTH);
        resultsCard.add(resultsBody, BorderLayout.CENTER);

        JPanel row = new JPanel(new GridLayout(1, 2, 16, 0));
        row.setOpaque(false);
        row.add(formCard);
        row.add(resultsCard);
        row.setPreferredSize(new Dimension(0, 330));

        JPanel body = new JPanel(new BorderLayout());
        body.setOpaque(false);
        body.add(row, BorderLayout.NORTH);

        add(UI.header("Profile", "Your numbers drive your daily calorie and macro targets."), BorderLayout.NORTH);
        add(body, BorderLayout.CENTER);
    }

    private void addRow(JPanel panel, String name, JLabel value) {
        panel.add(UI.label(name, Theme.BODY, Theme.MUTED));
        panel.add(value);
    }

    private void saveProfile() {
        try {
            String name = Validator.requireText(nameField.getText(), "Name");
            int age = Validator.parseInt(ageField.getText(), "Age", 10, 100);
            double weight = Validator.parseDouble(weightField.getText(), "Weight", 20, 300);
            double height = Validator.parseDouble(heightField.getText(), "Height", 100, 250);

            store.getProfile().update(name, age, (Gender) genderBox.getSelectedItem(),
                    weight, height, (Goal) goalBox.getSelectedItem());
            store.autoSave();
            refresh();
            JOptionPane.showMessageDialog(this, "Profile saved. Your targets were recalculated.",
                    "Saved", JOptionPane.INFORMATION_MESSAGE);
        } catch (InvalidInputException ex) {
            UI.error(this, ex.getMessage());
        }
    }

    @Override
    public void refresh() {
        Profile p = store.getProfile();
        nameField.setText(p.getName());
        ageField.setText(String.valueOf(p.getAge()));
        genderBox.setSelectedItem(p.getGender());
        weightField.setText(String.valueOf(p.getWeightKg()));
        heightField.setText(String.valueOf(p.getHeightCm()));
        goalBox.setSelectedItem(p.getGoal());

        bmiLabel.setText(String.format("%.1f", p.calculateBMI()));
        bmiNote.setText(p.getBMICategory());
        String category = p.getBMICategory();
        if (category.equals("Normal")) bmiLabel.setForeground(Theme.ACCENT);
        else if (category.equals("Underweight")) bmiLabel.setForeground(Theme.BLUE);
        else if (category.equals("Overweight")) bmiLabel.setForeground(Theme.ORANGE);
        else bmiLabel.setForeground(Theme.RED);

        bmrLabel.setText(String.format("%,.0f kcal / day", p.calculateBMR()));
        calLabel.setText(String.format("%,d kcal / day", p.getDailyCalorieGoal()));
        proteinLabel.setText(p.getProteinGoal() + " g");
        carbLabel.setText(p.getCarbGoal() + " g");
        fatLabel.setText(p.getFatGoal() + " g");
    }
}
