/** Enum of fitness goals. The adjustment changes the daily calorie target. */
public enum Goal {
    LOSE_WEIGHT("Lose Weight", -500),
    MAINTAIN("Maintain Weight", 0),
    GAIN_MUSCLE("Gain Muscle", 300);

    private final String label;
    private final int calorieAdjustment;

    Goal(String label, int calorieAdjustment) {
        this.label = label;
        this.calorieAdjustment = calorieAdjustment;
    }

    public int getCalorieAdjustment() { return calorieAdjustment; }

    @Override
    public String toString() { return label; }
}
