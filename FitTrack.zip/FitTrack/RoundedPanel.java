import java.awt.*;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

/** A panel with rounded corners and a solid fill - used for all dashboard "cards". */
public class RoundedPanel extends JPanel {
    private final Color fill;

    public RoundedPanel(Color fill, LayoutManager layout) {
        super(layout);
        this.fill = fill;
        setOpaque(false);
        setBorder(new EmptyBorder(16, 18, 16, 18));
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(fill);
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), 22, 22);
        g2.dispose();
        super.paintComponent(g);
    }
}
