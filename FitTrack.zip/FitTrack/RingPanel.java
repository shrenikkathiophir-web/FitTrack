import java.awt.*;
import java.awt.geom.Arc2D;
import javax.swing.JPanel;

/** Circular progress ring (like a donut chart) showing value compared to a goal. */
public class RingPanel extends JPanel {
    private int value;
    private int max = 1;
    private String caption = "";

    public RingPanel() {
        setOpaque(false);
        setPreferredSize(new Dimension(190, 170));
    }

    public void setData(int value, int max, String caption) {
        this.value = value;
        this.max = Math.max(1, max);
        this.caption = caption;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        int size = Math.min(getWidth(), getHeight()) - 24;
        int x = (getWidth() - size) / 2;
        int y = (getHeight() - size) / 2;
        double percent = (double) value / max;

        // background track
        g2.setStroke(new BasicStroke(14f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g2.setColor(Theme.FIELD);
        g2.drawOval(x, y, size, size);

        // progress arc (starts at top, goes clockwise)
        g2.setColor(percent > 1.0 ? Theme.ORANGE : Theme.ACCENT);
        double extent = -360.0 * Math.min(percent, 1.0);
        if (value > 0) {
            g2.draw(new Arc2D.Double(x, y, size, size, 90, extent, Arc2D.OPEN));
        }

        // text in the middle
        String big = String.format("%,d", value);
        String small = "of " + String.format("%,d", max) + " " + caption;
        g2.setFont(new Font("SansSerif", Font.BOLD, 26));
        FontMetrics fm = g2.getFontMetrics();
        g2.setColor(Theme.TEXT);
        g2.drawString(big, getWidth() / 2 - fm.stringWidth(big) / 2, getHeight() / 2 + 4);
        g2.setFont(Theme.SMALL);
        fm = g2.getFontMetrics();
        g2.setColor(Theme.MUTED);
        g2.drawString(small, getWidth() / 2 - fm.stringWidth(small) / 2, getHeight() / 2 + 22);
        g2.dispose();
    }
}
