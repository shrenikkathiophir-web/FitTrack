import java.awt.*;
import javax.swing.JPanel;

/** Horizontal progress bar with a name on the left and "value / goal" on the right. */
public class MacroBar extends JPanel {
    private final String name;
    private final Color color;
    private final String unit;
    private int value;
    private int goal = 1;

    public MacroBar(String name, Color color, String unit) {
        this.name = name;
        this.color = color;
        this.unit = unit;
        setOpaque(false);
        setPreferredSize(new Dimension(200, 38));
    }

    public void setData(int value, int goal) {
        this.value = value;
        this.goal = Math.max(1, goal);
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        int w = getWidth();
        g2.setFont(Theme.BODY_BOLD);
        g2.setColor(Theme.TEXT);
        g2.drawString(name, 0, 13);

        String right = value + " / " + goal + " " + unit;
        g2.setFont(Theme.BODY);
        g2.setColor(Theme.MUTED);
        g2.drawString(right, w - g2.getFontMetrics().stringWidth(right), 13);

        g2.setColor(Theme.FIELD);
        g2.fillRoundRect(0, 22, w, 9, 9, 9);
        int fillW = (int) (w * Math.min(1.0, (double) value / goal));
        if (fillW > 0) {
            g2.setColor(color);
            g2.fillRoundRect(0, 22, Math.max(fillW, 9), 9, 9, 9);
        }
        g2.dispose();
    }
}
