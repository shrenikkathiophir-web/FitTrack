import java.awt.*;
import javax.swing.JPanel;

/**
 * Custom-drawn bar chart (no external library) using Java 2D graphics.
 * Shows 7 bars, highlights today's bar and can draw a dashed goal line.
 */
public class ChartPanel extends JPanel {
    private final String title;
    private final Color color;
    private String[] labels;
    private int[] values;
    private int goal;

    public ChartPanel(String title, Color color) {
        this.title = title;
        this.color = color;
        setOpaque(false);
        setPreferredSize(new Dimension(300, 200));
    }

    public void setData(String[] labels, int[] values, int goal) {
        this.labels = labels;
        this.values = values;
        this.goal = goal;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        int w = getWidth();
        int h = getHeight();
        g2.setFont(Theme.HEADING);
        g2.setColor(Theme.TEXT);
        g2.drawString(title, 0, 16);

        if (values == null) {
            g2.dispose();
            return;
        }

        int left = 42, top = 36, bottom = 24;
        int chartW = w - left;
        int chartH = h - top - bottom;

        // choose a "nice" maximum for the y-axis
        int max = goal;
        for (int v : values) max = Math.max(max, v);
        int step = max <= 400 ? 100 : (max <= 1000 ? 250 : 500);
        int niceMax = Math.max(step, ((max + step - 1) / step) * step);

        g2.setFont(Theme.SMALL);
        FontMetrics fm = g2.getFontMetrics();

        // horizontal grid lines + y-axis numbers
        for (int i = 0; i <= 4; i++) {
            int y = top + chartH - (chartH * i / 4);
            g2.setColor(Theme.BORDER);
            g2.drawLine(left, y, w, y);
            String text = String.valueOf(niceMax * i / 4);
            g2.setColor(Theme.MUTED);
            g2.drawString(text, left - 8 - fm.stringWidth(text), y + 4);
        }

        // bars
        int n = values.length;
        int slot = chartW / n;
        int barW = slot * 55 / 100;
        for (int i = 0; i < n; i++) {
            int barH = (int) ((double) values[i] / niceMax * chartH);
            int x = left + i * slot + (slot - barW) / 2;
            int y = top + chartH - barH;
            boolean isToday = (i == n - 1);

            if (barH > 0) {
                g2.setColor(isToday ? color : new Color(color.getRed(), color.getGreen(), color.getBlue(), 110));
                g2.fillRoundRect(x, y, barW, barH + 6, 8, 8);
                g2.setColor(Theme.CARD);                      // hide the rounded bottom
                g2.fillRect(x - 1, top + chartH, barW + 2, 8);
                g2.setColor(Theme.TEXT);
                String v = String.valueOf(values[i]);
                g2.drawString(v, x + (barW - fm.stringWidth(v)) / 2, y - 4);
            }
            g2.setColor(isToday ? Theme.TEXT : Theme.MUTED);
            g2.drawString(labels[i], x + (barW - fm.stringWidth(labels[i])) / 2, h - 6);
        }

        // redraw the base line (the bars' rounded-bottom cover hides part of it)
        g2.setColor(Theme.BORDER);
        g2.drawLine(left, top + chartH, w, top + chartH);

        // dashed goal line
        if (goal > 0) {
            int gy = top + chartH - (int) ((double) goal / niceMax * chartH);
            g2.setColor(new Color(255, 255, 255, 170));
            g2.setStroke(new BasicStroke(1.2f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER,
                    10f, new float[]{5f, 4f}, 0f));
            g2.drawLine(left, gy, w, gy);
            g2.setStroke(new BasicStroke(1f));
            String text = "Goal " + goal;
            g2.drawString(text, w - fm.stringWidth(text), gy - 4);
        }
        g2.dispose();
    }
}
