import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.plaf.basic.BasicArrowButton;
import javax.swing.plaf.basic.BasicComboBoxUI;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

/**
 * Helper methods that create consistently styled Swing components.
 * (Avoids repeating the same styling code in every screen.)
 */
public class UI {

    public static JLabel label(String text, Font font, Color color) {
        JLabel l = new JLabel(text);
        l.setFont(font);
        l.setForeground(color);
        return l;
    }

    public static JButton button(String text, Color background, Color foreground) {
        JButton b = new JButton(text);
        b.setFont(Theme.BODY_BOLD);
        b.setBackground(background);
        b.setForeground(foreground);
        b.setOpaque(true);
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setBorder(new EmptyBorder(9, 18, 9, 18));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    public static JTextField field(String text, int columns) {
        JTextField f = new JTextField(text, columns);
        f.setFont(Theme.BODY);
        f.setBackground(Theme.FIELD);
        f.setForeground(Theme.TEXT);
        f.setCaretColor(Theme.ACCENT);
        f.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(Theme.BORDER, 1, true), new EmptyBorder(6, 8, 6, 8)));
        return f;
    }

    public static <T> JComboBox<T> combo(T[] items) {
        JComboBox<T> c = new JComboBox<>(items);
        c.setFont(Theme.BODY);
        c.setBackground(Theme.FIELD);
        c.setForeground(Theme.TEXT);
        c.setBorder(new LineBorder(Theme.BORDER, 1, true));
        // custom arrow button so the arrow is visible on the dark background
        c.setUI(new BasicComboBoxUI() {
            @Override
            protected JButton createArrowButton() {
                BasicArrowButton arrow = new BasicArrowButton(BasicArrowButton.SOUTH,
                        Theme.FIELD, Theme.FIELD, Theme.ACCENT, Theme.FIELD);
                arrow.setBorder(BorderFactory.createEmptyBorder());
                return arrow;
            }
        });
        return c;
    }

    /** A small caption above an input component. */
    public static JPanel labeled(String caption, JComponent component) {
        JPanel p = new JPanel(new BorderLayout(0, 4));
        p.setOpaque(false);
        p.add(label(caption, Theme.SMALL, Theme.MUTED), BorderLayout.NORTH);
        p.add(component, BorderLayout.CENTER);
        return p;
    }

    /** Page title + subtitle used at the top of every screen. */
    public static JPanel header(String title, String subtitle) {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setOpaque(false);
        p.add(label(title, Theme.TITLE, Theme.TEXT));
        p.add(Box.createVerticalStrut(2));
        p.add(label(subtitle, Theme.BODY, Theme.MUTED));
        return p;
    }

    public static RoundedPanel statCard(String title, String value, String sub, Color accent) {
        RoundedPanel card = new RoundedPanel(Theme.CARD, new BorderLayout(0, 2));
        card.add(label(title, Theme.BODY, Theme.MUTED), BorderLayout.NORTH);
        card.add(label(value, Theme.BIG, accent), BorderLayout.CENTER);
        card.add(label(sub, Theme.SMALL, Theme.MUTED), BorderLayout.SOUTH);
        return card;
    }

    /** Table model whose cells cannot be edited by the user. */
    public static DefaultTableModel model(String... columns) {
        return new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
    }

    public static JTable table(DefaultTableModel model) {
        JTable t = new JTable(model);
        t.setFont(Theme.BODY);
        t.setForeground(Theme.TEXT);
        t.setBackground(Theme.CARD);
        t.setRowHeight(30);
        t.setShowGrid(false);
        t.setIntercellSpacing(new Dimension(0, 0));
        t.setSelectionBackground(new Color(30, 110, 70));
        t.setSelectionForeground(Color.WHITE);
        t.setFillsViewportHeight(true);

        // body cells: add some left/right padding
        t.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean selected, boolean focus, int row, int col) {
                super.getTableCellRendererComponent(table, value, selected, false, row, col);
                setBorder(new EmptyBorder(0, 10, 0, 10));
                return this;
            }
        });

        // header cells: flat, muted text
        JTableHeader header = t.getTableHeader();
        header.setReorderingAllowed(false);
        header.setDefaultRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean selected, boolean focus, int row, int col) {
                super.getTableCellRendererComponent(table, value, false, false, row, col);
                setOpaque(true);
                setBackground(Theme.SIDEBAR);
                setForeground(Theme.MUTED);
                setFont(Theme.BODY_BOLD);
                setHorizontalAlignment(SwingConstants.LEFT);
                setBorder(new EmptyBorder(0, 10, 0, 10));
                return this;
            }
        });
        header.setPreferredSize(new Dimension(100, 32));
        return t;
    }

    public static JScrollPane scroll(JTable table) {
        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(null);
        sp.getViewport().setBackground(Theme.CARD);
        return sp;
    }

    public static void error(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "Please check your input", JOptionPane.WARNING_MESSAGE);
    }
}
