import java.awt.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

/** Screen for logging today's meals, tracking macros and water intake. */
public class NutritionPanel extends JPanel implements Refreshable {

    private final DataStore store;
    private final RingPanel ring = new RingPanel();
    private final MacroBar proteinBar = new MacroBar("Protein", Theme.ACCENT, "g");
    private final MacroBar carbBar = new MacroBar("Carbs", Theme.PURPLE, "g");
    private final MacroBar fatBar = new MacroBar("Fat", Theme.ORANGE, "g");
    private final MacroBar waterBar = new MacroBar("Water", Theme.BLUE, "ml");

    private final JTextField nameField = UI.field("", 13);
    private final JComboBox<MealType> typeBox = UI.combo(MealType.values());
    private final JTextField calField = UI.field("", 5);
    private final JTextField proteinField = UI.field("0", 4);
    private final JTextField carbField = UI.field("0", 4);
    private final JTextField fatField = UI.field("0", 4);

    private final DefaultTableModel model = UI.model("Meal", "Food", "Calories", "Protein (g)", "Carbs (g)", "Fat (g)");
    private final JTable table = UI.table(model);
    private List<Meal> shown = new ArrayList<>();

    public NutritionPanel(DataStore store) {
        this.store = store;
        setBackground(Theme.BG);
        setLayout(new BorderLayout(0, 16));
        setBorder(new EmptyBorder(24, 28, 24, 28));

        // --- top row: ring, macros, water ---
        RoundedPanel ringCard = new RoundedPanel(Theme.CARD, new BorderLayout(0, 4));
        ringCard.add(UI.label("Daily Calories", Theme.HEADING, Theme.TEXT), BorderLayout.NORTH);
        ringCard.add(ring, BorderLayout.CENTER);

        RoundedPanel macroCard = new RoundedPanel(Theme.CARD, new BorderLayout(0, 8));
        macroCard.add(UI.label("Macronutrients", Theme.HEADING, Theme.TEXT), BorderLayout.NORTH);
        JPanel bars = new JPanel(new GridLayout(3, 1, 0, 10));
        bars.setOpaque(false);
        bars.add(proteinBar);
        bars.add(carbBar);
        bars.add(fatBar);
        macroCard.add(bars, BorderLayout.CENTER);

        JButton water250 = UI.button("+ 250 ml", Theme.BLUE, Theme.BG);
        JButton water500 = UI.button("+ 500 ml", Theme.BLUE, Theme.BG);
        water250.addActionListener(e -> addWater(250));
        water500.addActionListener(e -> addWater(500));
        JPanel waterButtons = new JPanel(new GridLayout(1, 2, 10, 0));
        waterButtons.setOpaque(false);
        waterButtons.add(water250);
        waterButtons.add(water500);

        RoundedPanel waterCard = new RoundedPanel(Theme.CARD, new BorderLayout(0, 14));
        waterCard.add(UI.label("Water Intake", Theme.HEADING, Theme.TEXT), BorderLayout.NORTH);
        JPanel waterMiddle = new JPanel(new BorderLayout());
        waterMiddle.setOpaque(false);
        waterMiddle.add(waterBar, BorderLayout.NORTH);
        waterCard.add(waterMiddle, BorderLayout.CENTER);
        waterCard.add(waterButtons, BorderLayout.SOUTH);

        JPanel topRow = new JPanel(new GridLayout(1, 3, 16, 0));
        topRow.setOpaque(false);
        topRow.setPreferredSize(new Dimension(0, 200));
        topRow.add(ringCard);
        topRow.add(macroCard);
        topRow.add(waterCard);

        // --- meal form ---
        JButton addButton = UI.button("Add Meal", Theme.ACCENT, Theme.BG);
        addButton.addActionListener(e -> addMeal());
        JPanel formRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        formRow.setOpaque(false);
        formRow.add(UI.labeled("Food name", nameField));
        formRow.add(UI.labeled("Meal", typeBox));
        formRow.add(UI.labeled("Calories", calField));
        formRow.add(UI.labeled("Protein g", proteinField));
        formRow.add(UI.labeled("Carbs g", carbField));
        formRow.add(UI.labeled("Fat g", fatField));
        JPanel buttonWrap = new JPanel(new BorderLayout());
        buttonWrap.setOpaque(false);
        buttonWrap.add(Box.createVerticalStrut(18), BorderLayout.NORTH);
        buttonWrap.add(addButton, BorderLayout.CENTER);
        formRow.add(buttonWrap);

        RoundedPanel formCard = new RoundedPanel(Theme.CARD, new BorderLayout(0, 10));
        formCard.add(UI.label("Log a Meal (today)", Theme.HEADING, Theme.TEXT), BorderLayout.NORTH);
        formCard.add(formRow, BorderLayout.CENTER);

        // --- meals table ---
        JButton deleteButton = UI.button("Delete Selected", Theme.RED, Color.WHITE);
        deleteButton.addActionListener(e -> deleteSelected());
        JPanel deleteWrap = new JPanel(new BorderLayout());
        deleteWrap.setOpaque(false);
        deleteWrap.add(deleteButton, BorderLayout.EAST);

        RoundedPanel tableCard = new RoundedPanel(Theme.CARD, new BorderLayout(0, 10));
        tableCard.add(UI.label("Today's Meals", Theme.HEADING, Theme.TEXT), BorderLayout.NORTH);
        tableCard.add(UI.scroll(table), BorderLayout.CENTER);
        tableCard.add(deleteWrap, BorderLayout.SOUTH);

        JPanel lower = new JPanel(new BorderLayout(0, 16));
        lower.setOpaque(false);
        lower.add(formCard, BorderLayout.NORTH);
        lower.add(tableCard, BorderLayout.CENTER);

        JPanel body = new JPanel(new BorderLayout(0, 16));
        body.setOpaque(false);
        body.add(topRow, BorderLayout.NORTH);
        body.add(lower, BorderLayout.CENTER);

        table.getColumnModel().getColumn(1).setPreferredWidth(260);   // wider "Food" column
        add(UI.header("Nutrition", "Track calories, macros and hydration."), BorderLayout.NORTH);
        add(body, BorderLayout.CENTER);
    }

    private void addMeal() {
        try {
            String name = Validator.requireText(nameField.getText(), "Food name");
            MealType type = (MealType) typeBox.getSelectedItem();
            int calories = Validator.parseInt(calField.getText(), "Calories", 1, 5000);
            int protein = Validator.parseInt(proteinField.getText(), "Protein", 0, 500);
            int carbs = Validator.parseInt(carbField.getText(), "Carbs", 0, 1000);
            int fat = Validator.parseInt(fatField.getText(), "Fat", 0, 500);

            store.addMeal(new Meal(LocalDate.now(), name, type, calories, protein, carbs, fat));
            nameField.setText("");
            calField.setText("");
            proteinField.setText("0");
            carbField.setText("0");
            fatField.setText("0");
            refresh();
        } catch (InvalidInputException ex) {
            UI.error(this, ex.getMessage());
        }
    }

    private void deleteSelected() {
        int row = table.getSelectedRow();
        if (row < 0) {
            UI.error(this, "Please select a meal in the table first.");
            return;
        }
        store.removeMeal(shown.get(row));
        refresh();
    }

    private void addWater(int ml) {
        store.addWater(LocalDate.now(), ml);
        refresh();
    }

    @Override
    public void refresh() {
        LocalDate today = LocalDate.now();
        Profile p = store.getProfile();

        ring.setData(store.caloriesEaten(today), p.getDailyCalorieGoal(), "kcal");
        proteinBar.setData(store.proteinOn(today), p.getProteinGoal());
        carbBar.setData(store.carbsOn(today), p.getCarbGoal());
        fatBar.setData(store.fatOn(today), p.getFatGoal());
        waterBar.setData(store.getWater(today), DataStore.WATER_GOAL_ML);

        shown = store.mealsOn(today);
        model.setRowCount(0);
        for (Meal m : shown) {
            model.addRow(new Object[]{m.getCategory(), m.getName(), m.getCalories() + " kcal",
                    m.getProtein(), m.getCarbs(), m.getFat()});
        }
    }
}
