import java.time.LocalDate;

/** A single food item that was eaten. INHERITANCE: extends Entry. */
public class Meal extends Entry {
    private final MealType mealType;
    private final int calories;
    private final int protein;
    private final int carbs;
    private final int fat;

    public Meal(LocalDate date, String name, MealType mealType,
                int calories, int protein, int carbs, int fat) {
        super(date, name);
        this.mealType = mealType;
        this.calories = calories;
        this.protein = protein;
        this.carbs = carbs;
        this.fat = fat;
    }

    public MealType getMealType() { return mealType; }
    public int getProtein() { return protein; }
    public int getCarbs() { return carbs; }
    public int getFat() { return fat; }

    @Override
    public int getCalories() { return calories; }

    @Override
    public String getCategory() { return mealType.getLabel(); }

    @Override
    public String toFileString() {
        return "MEAL|" + getDate() + "|" + getName() + "|" + mealType.name()
                + "|" + calories + "|" + protein + "|" + carbs + "|" + fat;
    }

    public static Meal fromFileString(String[] p) {
        return new Meal(LocalDate.parse(p[1]), p[2], MealType.valueOf(p[3]),
                Integer.parseInt(p[4]), Integer.parseInt(p[5]),
                Integer.parseInt(p[6]), Integer.parseInt(p[7]));
    }
}
