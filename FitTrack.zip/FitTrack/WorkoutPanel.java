import java.awt.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

/** Screen for logging workouts. Calories burned are calculated automatically. */
public class WorkoutPanel extends JPanel implements Refreshable {

    private final DataStore store;
    private final JTextField dateField = UI.field(LocalDate.now().toString(), 9);
    private final JTextField nameField = UI.field("", 14);
    private final JComboBox<WorkoutType> typeBox = UI.combo(WorkoutType.values());
    private final JTextField minutesField = UI.field("", 5);
    private final JLabel summary = UI.label("", Theme.BODY, Theme.MUTED);
    private final DefaultTableModel model = UI.model("Date", "Workout", "Type", "Minutes", "Calories Burned");
    private final JTable table = UI.table(model);
    private List<Workout> shown = new ArrayList<>();

    public WorkoutPanel(DataStore store) {
        this.store = store;
        setBackground(Theme.BG);
        setLayout(new BorderLayout(0, 18));
        setBorder(new EmptyBorder(24, 28, 24, 28));

        // form card
        JButton addButton = UI.button("Add Workout", Theme.ACCENT, Theme.BG);
        addButton.addActionListener(e -> addWorkout());

        JPanel formRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 14, 0));
        formRow.setOpaque(false);
        formRow.add(UI.labeled("Date (yyyy-MM-dd)", dateField));
        formRow.add(UI.labeled("Workout name (optional)", nameField));
        formRow.add(UI.labeled("Type", typeBox));
        formRow.add(UI.labeled("Minutes", minutesField));
        JPanel buttonWrap = new JPanel(new BorderLayout());
        buttonWrap.setOpaque(false);
        buttonWrap.add(Box.createVerticalStrut(18), BorderLayout.NORTH);
        buttonWrap.add(addButton, BorderLayout.CENTER);
        formRow.add(buttonWrap);

        RoundedPanel formCard = new RoundedPanel(Theme.CARD, new BorderLayout(0, 10));
        formCard.add(UI.label("Log a Workout", Theme.HEADING, Theme.TEXT), BorderLayout.NORTH);
        formCard.add(formRow, BorderLayout.CENTER);

        // table card
        JButton deleteButton = UI.button("Delete Selected", Theme.RED, Color.WHITE);
        deleteButton.addActionListener(e -> deleteSelected());

        JPanel bottomBar = new JPanel(new BorderLayout());
        bottomBar.setOpaque(false);
        bottomBar.add(summary, BorderLayout.WEST);
        bottomBar.add(deleteButton, BorderLayout.EAST);

        RoundedPanel tableCard = new RoundedPanel(Theme.CARD, new BorderLayout(0, 10));
        tableCard.add(UI.label("Workout History", Theme.HEADING, Theme.TEXT), BorderLayout.NORTH);
        tableCard.add(UI.scroll(table), BorderLayout.CENTER);
        tableCard.add(bottomBar, BorderLayout.SOUTH);

        JPanel body = new JPanel(new BorderLayout(0, 18));
        body.setOpaque(false);
        body.add(formCard, BorderLayout.NORTH);
        body.add(tableCard, BorderLayout.CENTER);

        add(UI.header("Workouts", "Log your sessions and watch the calories add up."), BorderLayout.NORTH);
        add(body, BorderLayout.CENTER);
    }

    private void addWorkout() {
        try {
            LocalDate date = Validator.parseDate(dateField.getText());
            WorkoutType type = (WorkoutType) typeBox.getSelectedItem();
            int minutes = Validator.parseInt(minutesField.getText(), "Minutes", 1, 600);
            String name = nameField.getText().trim().isEmpty()
                    ? type.getLabel()
                    : Validator.requireText(nameField.getText(), "Workout name");

            int calories = type.caloriesBurned(store.getProfile().getWeightKg(), minutes);
            store.addWorkout(new Workout(date, name, type, minutes, calories));

            nameField.setText("");
            minutesField.setText("");
            refresh();
            JOptionPane.showMessageDialog(this, name + " added - about " + calories + " kcal burned.",
                    "Workout saved", JOptionPane.INFORMATION_MESSAGE);
        } catch (InvalidInputException ex) {
            UI.error(this, ex.getMessage());
        }
    }

    private void deleteSelected() {
        int row = table.getSelectedRow();
        if (row < 0) {
            UI.error(this, "Please select a workout in the table first.");
            return;
        }
        int answer = JOptionPane.showConfirmDialog(this, "Delete this workout?",
                "Confirm", JOptionPane.YES_NO_OPTION);
        if (answer == JOptionPane.YES_OPTION) {
            store.removeWorkout(shown.get(row));
            refresh();
        }
    }

    @Override
    public void refresh() {
        shown = store.getWorkoutsNewestFirst();
        model.setRowCount(0);
        for (Workout w : shown) {
            model.addRow(new Object[]{w.getDate(), w.getName(), w.getCategory(),
                    w.getMinutes(), w.getCalories() + " kcal"});
        }
        summary.setText("Total: " + store.totalWorkouts() + " workouts  |  "
                + store.totalMinutes() + " minutes  |  "
                + store.totalCaloriesBurned() + " kcal burned");
    }
}
