import java.time.LocalDate;

/** A single workout session. INHERITANCE: extends Entry. */
public class Workout extends Entry {
    private final WorkoutType type;
    private final int minutes;
    private final int caloriesBurned;

    public Workout(LocalDate date, String name, WorkoutType type, int minutes, int caloriesBurned) {
        super(date, name);
        this.type = type;
        this.minutes = minutes;
        this.caloriesBurned = caloriesBurned;
    }

    public WorkoutType getType() { return type; }
    public int getMinutes() { return minutes; }

    @Override
    public int getCalories() { return caloriesBurned; }

    @Override
    public String getCategory() { return type.getLabel(); }

    @Override
    public String toFileString() {
        return "WORKOUT|" + getDate() + "|" + getName() + "|" + type.name()
                + "|" + minutes + "|" + caloriesBurned;
    }

    public static Workout fromFileString(String[] p) {
        return new Workout(LocalDate.parse(p[1]), p[2], WorkoutType.valueOf(p[3]),
                Integer.parseInt(p[4]), Integer.parseInt(p[5]));
    }
}
