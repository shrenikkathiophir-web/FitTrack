/**
 * The user's body details and goal.
 * Implements HealthMetrics (INTERFACE) and keeps its fields private (ENCAPSULATION).
 */
public class Profile implements HealthMetrics {
    private static final double ACTIVITY_FACTOR = 1.4;   // lightly active

    private String name;
    private int age;
    private Gender gender;
    private double weightKg;
    private double heightCm;
    private Goal goal;

    public Profile(String name, int age, Gender gender, double weightKg, double heightCm, Goal goal) {
        update(name, age, gender, weightKg, heightCm, goal);
    }

    public static Profile defaultProfile() {
        return new Profile("Athlete", 20, Gender.MALE, 70, 175, Goal.MAINTAIN);
    }

    public void update(String name, int age, Gender gender, double weightKg, double heightCm, Goal goal) {
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.weightKg = weightKg;
        this.heightCm = heightCm;
        this.goal = goal;
    }

    public String getName() { return name; }
    public int getAge() { return age; }
    public Gender getGender() { return gender; }
    public double getWeightKg() { return weightKg; }
    public double getHeightCm() { return heightCm; }
    public Goal getGoal() { return goal; }

    @Override
    public double calculateBMI() {
        double heightM = heightCm / 100.0;
        return weightKg / (heightM * heightM);
    }

    @Override
    public String getBMICategory() {
        double bmi = calculateBMI();
        if (bmi < 18.5) return "Underweight";
        else if (bmi < 25) return "Normal";
        else if (bmi < 30) return "Overweight";
        else return "Obese";
    }

    /** Mifflin-St Jeor equation: calories the body burns at rest per day. */
    @Override
    public double calculateBMR() {
        double base = 10 * weightKg + 6.25 * heightCm - 5 * age;
        return gender == Gender.MALE ? base + 5 : base - 161;
    }

    @Override
    public int getDailyCalorieGoal() {
        return (int) Math.round(calculateBMR() * ACTIVITY_FACTOR + goal.getCalorieAdjustment());
    }

    public int getProteinGoal() {
        return (int) Math.round(weightKg * 1.6);               // 1.6 g per kg
    }

    public int getFatGoal() {
        return (int) Math.round(getDailyCalorieGoal() * 0.25 / 9);   // 25% of calories
    }

    public int getCarbGoal() {
        int remaining = getDailyCalorieGoal() - getProteinGoal() * 4 - getFatGoal() * 9;
        return (int) Math.round(remaining / 4.0);
    }

    public String toFileString() {
        return "PROFILE|" + name + "|" + age + "|" + gender.name() + "|" + weightKg
                + "|" + heightCm + "|" + goal.name();
    }

    public static Profile fromFileString(String[] p) {
        return new Profile(p[1], Integer.parseInt(p[2]), Gender.valueOf(p[3]),
                Double.parseDouble(p[4]), Double.parseDouble(p[5]), Goal.valueOf(p[6]));
    }
}
