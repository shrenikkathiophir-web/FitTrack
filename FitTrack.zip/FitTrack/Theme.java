import java.awt.Color;
import java.awt.Font;
import javax.swing.UIManager;

/**
 * Central place for all colours and fonts (dark gym theme with neon green accent).
 * Keeping them here means the whole look can be changed in one file.
 */
public class Theme {
    public static final Color BG      = new Color(16, 17, 20);
    public static final Color SIDEBAR = new Color(22, 23, 27);
    public static final Color CARD    = new Color(32, 34, 40);
    public static final Color FIELD   = new Color(44, 46, 54);
    public static final Color BORDER  = new Color(62, 65, 74);
    public static final Color TEXT    = new Color(236, 238, 242);
    public static final Color MUTED   = new Color(143, 148, 160);
    public static final Color ACCENT  = new Color(57, 255, 136);   // neon green
    public static final Color ORANGE  = new Color(255, 159, 67);
    public static final Color BLUE    = new Color(84, 160, 255);
    public static final Color PURPLE  = new Color(165, 105, 245);
    public static final Color RED      = new Color(255, 94, 98);

    public static final Font TITLE     = new Font("SansSerif", Font.BOLD, 26);
    public static final Font HEADING   = new Font("SansSerif", Font.BOLD, 16);
    public static final Font BIG       = new Font("SansSerif", Font.BOLD, 30);
    public static final Font BODY      = new Font("SansSerif", Font.PLAIN, 13);
    public static final Font BODY_BOLD = new Font("SansSerif", Font.BOLD, 13);
    public static final Font SMALL     = new Font("SansSerif", Font.PLAIN, 11);

    /** Applies the dark colours to standard Swing components (dialogs, combo boxes, scrollbars). */
    public static void install() {
        try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        } catch (Exception e) {
            // keep the default look and feel
        }
        UIManager.put("Panel.background", BG);
        UIManager.put("Table.scrollPaneBorder", new javax.swing.border.EmptyBorder(0, 0, 0, 0));
        UIManager.put("OptionPane.background", CARD);
        UIManager.put("OptionPane.messageForeground", TEXT);
        UIManager.put("OptionPane.messageFont", BODY);
        UIManager.put("OptionPane.buttonFont", BODY);
        UIManager.put("Button.background", FIELD);
        UIManager.put("Button.foreground", TEXT);
        UIManager.put("ComboBox.background", FIELD);
        UIManager.put("ComboBox.foreground", TEXT);
        UIManager.put("ComboBox.selectionBackground", ACCENT);
        UIManager.put("ComboBox.selectionForeground", BG);
        UIManager.put("ComboBox.buttonBackground", FIELD);
        UIManager.put("ScrollBar.background", CARD);
        UIManager.put("ScrollBar.track", CARD);
        UIManager.put("ScrollBar.thumb", BORDER);
        UIManager.put("ScrollBar.thumbShadow", BORDER);
        UIManager.put("ScrollBar.thumbHighlight", BORDER);
        UIManager.put("ScrollBar.thumbDarkShadow", BORDER);
    }
}
