/**
 * Interface for any screen that can reload its data from the DataStore.
 * Every screen (Dashboard, Workouts, ...) implements this contract.
 */
public interface Refreshable {
    void refresh();
}
