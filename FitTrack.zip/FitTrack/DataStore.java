import java.io.*;
import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Holds ALL application data (profile, workouts, meals, water) and the calculations on it.
 * Also handles saving to / loading from a text file (FILE I/O), so data survives restarts.
 */
public class DataStore {

    private static final String FILE_NAME = "fittrack_data.txt";
    public static final int WATER_GOAL_ML = 2500;

    private Profile profile = Profile.defaultProfile();
    private final List<Workout> workouts = new ArrayList<>();
    private final List<Meal> meals = new ArrayList<>();
    private final Map<LocalDate, Integer> water = new HashMap<>();

    public Profile getProfile() { return profile; }

    // ---------------- adding / removing ----------------
    public void addWorkout(Workout w) { workouts.add(w); autoSave(); }
    public void removeWorkout(Workout w) { workouts.remove(w); autoSave(); }
    public void addMeal(Meal m) { meals.add(m); autoSave(); }
    public void removeMeal(Meal m) { meals.remove(m); autoSave(); }

    public void addWater(LocalDate date, int ml) {
        water.put(date, getWater(date) + ml);
        autoSave();
    }

    public int getWater(LocalDate date) {
        return water.getOrDefault(date, 0);
    }

    // ---------------- queries ----------------
    public List<Workout> getWorkoutsNewestFirst() {
        List<Workout> copy = new ArrayList<>(workouts);
        copy.sort(Comparator.comparing(Workout::getDate).reversed());
        return copy;
    }

    public List<Workout> getRecentWorkouts(int count) {
        List<Workout> all = getWorkoutsNewestFirst();
        return all.subList(0, Math.min(count, all.size()));
    }

    public List<Meal> mealsOn(LocalDate date) {
        List<Meal> result = new ArrayList<>();
        for (Meal m : meals) {
            if (m.getDate().equals(date)) {
                result.add(m);
            }
        }
        result.sort(Comparator.comparingInt((Meal m) -> m.getMealType().ordinal()));
        return result;
    }

    public int caloriesBurned(LocalDate date) {
        int total = 0;
        for (Workout w : workouts) {
            if (w.getDate().equals(date)) total += w.getCalories();
        }
        return total;
    }

    public int caloriesEaten(LocalDate date) {
        int total = 0;
        for (Meal m : mealsOn(date)) total += m.getCalories();
        return total;
    }

    public int proteinOn(LocalDate date) {
        int total = 0;
        for (Meal m : mealsOn(date)) total += m.getProtein();
        return total;
    }

    public int carbsOn(LocalDate date) {
        int total = 0;
        for (Meal m : mealsOn(date)) total += m.getCarbs();
        return total;
    }

    public int fatOn(LocalDate date) {
        int total = 0;
        for (Meal m : mealsOn(date)) total += m.getFat();
        return total;
    }

    // ---------------- weekly data for charts ----------------
    public int[] burnedLast7Days() {
        int[] result = new int[7];
        for (int i = 0; i < 7; i++) {
            result[i] = caloriesBurned(LocalDate.now().minusDays(6 - i));
        }
        return result;
    }

    public int[] eatenLast7Days() {
        int[] result = new int[7];
        for (int i = 0; i < 7; i++) {
            result[i] = caloriesEaten(LocalDate.now().minusDays(6 - i));
        }
        return result;
    }

    public String[] last7DayLabels() {
        String[] labels = new String[7];
        for (int i = 0; i < 7; i++) {
            LocalDate d = LocalDate.now().minusDays(6 - i);
            labels[i] = d.getDayOfWeek().getDisplayName(TextStyle.SHORT, Locale.ENGLISH);
        }
        return labels;
    }

    // ---------------- statistics ----------------
    private boolean hasWorkoutOn(LocalDate date) {
        for (Workout w : workouts) {
            if (w.getDate().equals(date)) return true;
        }
        return false;
    }

    /** Number of consecutive days (ending today or yesterday) with at least one workout. */
    public int getWorkoutStreak() {
        LocalDate day = LocalDate.now();
        if (!hasWorkoutOn(day)) {
            day = day.minusDays(1);
        }
        int streak = 0;
        while (hasWorkoutOn(day)) {
            streak++;
            day = day.minusDays(1);
        }
        return streak;
    }

    public int totalWorkouts() { return workouts.size(); }

    public int totalMinutes() {
        int total = 0;
        for (Workout w : workouts) total += w.getMinutes();
        return total;
    }

    public int totalCaloriesBurned() {
        int total = 0;
        for (Workout w : workouts) total += w.getCalories();
        return total;
    }

    // ---------------- file handling ----------------
    public void save() throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME))) {
            writer.write(profile.toFileString());
            writer.newLine();
            for (Workout w : workouts) {
                writer.write(w.toFileString());
                writer.newLine();
            }
            for (Meal m : meals) {
                writer.write(m.toFileString());
                writer.newLine();
            }
            for (Map.Entry<LocalDate, Integer> e : water.entrySet()) {
                writer.write("WATER|" + e.getKey() + "|" + e.getValue());
                writer.newLine();
            }
        }
    }

    /** Saves without forcing the caller to handle the exception. */
    public void autoSave() {
        try {
            save();
        } catch (IOException e) {
            System.out.println("Warning: could not save data - " + e.getMessage());
        }
    }

    public void load() throws IOException {
        File file = new File(FILE_NAME);
        if (!file.exists()) {
            return;   // first run: keep defaults
        }
        workouts.clear();
        meals.clear();
        water.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] p = line.split("\\|", -1);
                try {
                    switch (p[0]) {
                        case "PROFILE": profile = Profile.fromFileString(p); break;
                        case "WORKOUT": workouts.add(Workout.fromFileString(p)); break;
                        case "MEAL":    meals.add(Meal.fromFileString(p)); break;
                        case "WATER":   water.put(LocalDate.parse(p[1]), Integer.parseInt(p[2])); break;
                        default: break;
                    }
                } catch (RuntimeException e) {
                    System.out.println("Skipped a bad line: " + line);
                }
            }
        }
    }

    // ---------------- demo data ----------------
    /** Replaces all data with a realistic week of sample entries (useful for demos). */
    public void loadSampleData() {
        workouts.clear();
        meals.clear();
        water.clear();
        profile = new Profile("Alex", 21, Gender.MALE, 72, 178, Goal.LOSE_WEIGHT);

        WorkoutType[] types = {WorkoutType.RUNNING, WorkoutType.STRENGTH, WorkoutType.CYCLING,
                WorkoutType.HIIT, WorkoutType.YOGA, WorkoutType.WALKING, WorkoutType.RUNNING};
        String[] names = {"Morning City Run", "Upper Body Strength", "Evening Ride",
                "HIIT Circuit", "Yoga Flow", "Park Walk", "Interval Run"};
        int[] minutes = {40, 55, 45, 30, 35, 50, 35};

        LocalDate today = LocalDate.now();
        for (int i = 0; i < 7; i++) {
            if (i == 2) continue;                       // a rest day
            LocalDate day = today.minusDays(6 - i);
            int cal = types[i].caloriesBurned(profile.getWeightKg(), minutes[i]);
            workouts.add(new Workout(day, names[i], types[i], minutes[i], cal));
        }

        for (int i = 0; i < 7; i++) {
            LocalDate day = today.minusDays(6 - i);
            int wobble = (i * 37) % 140 - 60;           // small daily variation
            meals.add(new Meal(day, "Oatmeal with Berries", MealType.BREAKFAST, 380, 14, 62, 8));
            meals.add(new Meal(day, "Grilled Chicken Bowl", MealType.LUNCH, 620 + wobble, 48, 60, 16));
            meals.add(new Meal(day, "Greek Yogurt", MealType.SNACK, 150, 15, 12, 4));
            if (i < 6) {                                // today's dinner not eaten yet
                meals.add(new Meal(day, "Salmon & Quinoa", MealType.DINNER, 590 + wobble, 42, 45, 22));
            }
            water.put(day, i == 6 ? 1250 : 1800 + (i * 150) % 800);
        }
        autoSave();
    }
}
