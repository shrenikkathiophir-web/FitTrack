import java.time.LocalDate;

/**
 * Abstract parent of everything the user logs (workouts and meals).
 * Demonstrates ABSTRACTION: shared data lives here, each child defines its own details.
 */
public abstract class Entry {
    private final LocalDate date;
    private final String name;

    public Entry(LocalDate date, String name) {
        this.date = date;
        this.name = name;
    }

    public LocalDate getDate() { return date; }
    public String getName() { return name; }

    /** Calories for this entry (burned for a workout, eaten for a meal). */
    public abstract int getCalories();

    /** A short category text, e.g. "Running" or "Lunch". */
    public abstract String getCategory();

    /** One line of text used to save this entry to the data file. */
    public abstract String toFileString();
}
