import java.time.LocalDate;
import java.time.format.DateTimeParseException;

/**
 * Static helper methods that check and convert text typed by the user.
 * Each method throws InvalidInputException with a clear message on bad input.
 */
public class Validator {

    public static String requireText(String value, String field) throws InvalidInputException {
        if (value == null || value.trim().isEmpty()) {
            throw new InvalidInputException(field + " cannot be empty.");
        }
        return value.trim().replace("|", "/");   // '|' is our file separator
    }

    public static int parseInt(String value, String field, int min, int max) throws InvalidInputException {
        int number;
        try {
            number = Integer.parseInt(value.trim());
        } catch (NumberFormatException e) {
            throw new InvalidInputException(field + " must be a whole number.");
        }
        if (number < min || number > max) {
            throw new InvalidInputException(field + " must be between " + min + " and " + max + ".");
        }
        return number;
    }

    public static double parseDouble(String value, String field, double min, double max) throws InvalidInputException {
        double number;
        try {
            number = Double.parseDouble(value.trim());
        } catch (NumberFormatException e) {
            throw new InvalidInputException(field + " must be a number.");
        }
        if (number < min || number > max) {
            throw new InvalidInputException(field + " must be between " + min + " and " + max + ".");
        }
        return number;
    }

    public static LocalDate parseDate(String value) throws InvalidInputException {
        try {
            return LocalDate.parse(value.trim());
        } catch (DateTimeParseException e) {
            throw new InvalidInputException("Date must be in yyyy-MM-dd format (e.g. 2026-11-01).");
        }
    }
}
